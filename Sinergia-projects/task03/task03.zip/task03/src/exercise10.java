import java.util.Scanner;

public class exercise10 {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Введите BOOLEAN значение:");
        boolean bool = scanner.nextBoolean();

        if (bool) {
            System.out.println("ИСТИНА");
        }


    }
}
