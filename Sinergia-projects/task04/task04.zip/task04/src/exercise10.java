public class exercise10 {
    public static void main(String[] args) {
        char charA = 'j';
        int intA = charA;

        System.out.println(intA);

        int intB = 112;
        char charB = (char) intB;

        System.out.println(charB);
    }
}
