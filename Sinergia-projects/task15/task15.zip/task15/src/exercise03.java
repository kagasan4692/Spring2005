public class exercise03 {
    public static void main(String[] args) {
        final String string = "Squash";

//        string = "sdfgdfg";
        // Ошибка : Cannot assign a value to final variable 'string'
    }
}
