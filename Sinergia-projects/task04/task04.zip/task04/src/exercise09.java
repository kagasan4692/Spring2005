public class exercise09 {
    public static void main(String[] args) {

        char charA = 'j';
        String strA = Character.toString(charA);

        System.out.println(strA);

        //  OR

        String strB = String.valueOf(charA);

        System.out.println(strB);


    }
}
