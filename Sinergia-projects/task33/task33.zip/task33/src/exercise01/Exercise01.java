package exercise01;

public class Exercise01 {
    public static void main(String[] args) {
        XOGame game = new XOGame();
        game.play();
    }
}