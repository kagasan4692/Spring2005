public class exercise6 {
    public static void main(String[] args) {
        int first = 2;
        int second = 5;

        System.out.println(Math.pow(first, second));
        System.out.println(Math.pow(second, first));
    }
}
