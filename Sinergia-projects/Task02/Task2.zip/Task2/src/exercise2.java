public class exercise2 {
    public static void main(String[] args) {
        int a;
        a = 5;
//        a = -5;
        if (a > 0) {
            System.out.println("позитив");
        } else {
            System.out.println("отрицательно");
        }
    }
}
