public class Rectorate {
        String president;
        String rector;
}
