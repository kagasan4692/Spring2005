public class ProgrammingLanguage {
    String name;
    String[] typing;
    String[] version;
    String[] keywords;
}