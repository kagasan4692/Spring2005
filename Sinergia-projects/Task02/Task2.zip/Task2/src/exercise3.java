public class exercise3 {
    public static void main(String[] args) {
        int a = 15000000;

        double square = Math.sqrt(a);

        if (square < 5000) {
            System.out.println("Два измерения лучше, чем одно");
        }
    }
}
