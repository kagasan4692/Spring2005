public class exercise03 {
    public static void main(String[] args) {
        int i = 65;
        while(i <= 90){
            System.out.println((char) i + " " + (char) (i + 32));
            i++;
        }
    }

}
