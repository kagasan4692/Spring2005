import java.util.Locale;

public class exercise13 {
    public static void main(String[] args) {
        String str = "Практика программирования: переменные, ветвления, циклы";
        String strReplace = str.toUpperCase();
        System.out.println(strReplace);
    }
}
