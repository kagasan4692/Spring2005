public class Departments {
        String department;
}
