public class exercise06 {
    public static void main(String[] args) {

        double doubleA = 100001.1596536;
        float floatA = (float) doubleA;

        System.out.println(floatA);
    }
}
