public class exercise04 {
    public static void main(String[] args) {

        long longA = 10000001L;
        int intA = (int) longA;

        System.out.println(intA);
    }
}
