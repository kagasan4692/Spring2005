public class exercise08 {
    public static void main(String[] args) {
        for (int i = 945; i <= 969; i++) {
            if (i < 969) {
                System.out.printf((char) i + ", ");
            } else if (i == 969) {
                System.out.printf((char) i + ".");
            }

        }
    }
}
