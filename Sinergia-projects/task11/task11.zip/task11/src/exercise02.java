public class exercise02 {
    public static void main(String[] args) {
        double i = 1.5;
        while(i <= 101.5){
            System.out.println(i);
            i = i + 0.5;
        }
    }
}
