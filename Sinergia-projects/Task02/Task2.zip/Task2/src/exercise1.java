public class exercise1 {
    public static void main(String[] args) {
        int a = 5;
        int n = 15;
        double exponentiation = Math.pow(a, n);

        if (1000000000 < exponentiation) {
            System.out.println("Степень это мощь. Power is a power.");
        }
    }
}
