public class exercise10 {
    public static void main(String[] args) {
        int i = 101;
        while (i > 0) {
            i = i - 1;
            System.out.println(i);
        }
    }
}
