public class exercise07 {
    public static void main(String[] args) {
        String str = "Hell";

        while (str.length() < 10) {

            str = str + "o";

        }
    }
}
// метод str.length() вызывается 7 раз.