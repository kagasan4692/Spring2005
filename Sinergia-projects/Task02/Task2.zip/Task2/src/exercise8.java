public class exercise8 {
    public static void main(String[] args) {
        int i = 0;
        while (i < 100) {
            i = i + 1;
            System.out.println(i);
        }
    }
}
