public class exercise5 {
    public static void main(String[] args) {
        double a = 10.15;
        double b = 957.1475;

//        double a = 957.1475;
//        double b = 10.15;

        if (a < b) {
            System.out.println(b);
        } else {
            System.out.println(a);
        }
    }
}
