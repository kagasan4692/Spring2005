public class Exercise06 {
    public static void main(String[] args) {
// суммирование возможно только с числовыми значениями, поэтому пробуем так:
//        int integer = null + null;
// Получаем ошибку! "java.lang.Integer.intValue()"

    }


}