public class exercise14 {
    public static void main(String[] args) {
        String str = "Практика программирования: переменные, ветвления, циклы";
        String strReplace = str.replace("а", "@").replace("о", "0");
        System.out.println(strReplace);
    }
}
