public class Exercise02 {
    static class Person {
        String name;
    }

    public static void main(String[] args) {
        Person person = null;

        System.out.println(person.name);
    }
}
