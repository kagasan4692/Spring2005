public class exercise11 {
    public static void main(String[] args) {
        int i = 29;
        char charCode;
        while (i < 150 ){
            i++;
            charCode = (char) i;
            System.out.println(i + " - " + charCode);
        }
    }
}