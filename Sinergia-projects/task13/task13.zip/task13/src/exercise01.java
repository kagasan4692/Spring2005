public class exercise01 {
    public static void main(String[] args) {
        int romanNumeral = 8544;
        do {
            System.out.println((char) romanNumeral);
            romanNumeral++;
        } while (romanNumeral < 8560);
    }
}
