package point01;

import java.io.*;

public class CsvFileHandler extends FileHandler {
    @Override
    public void run() throws IOException {
        processTransactionFile();
    }

    public CsvFileHandler(String filePath) {
        super(filePath);
    }

    @Override
    public void write(String content) throws IOException {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(content);
        }
    }

    @Override
    public String read() throws IOException {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().equals("")) {
                    content.append(line).append("\n");
                } else {
                    break;
                }
            }
        } catch (IOException e) {
            System.out.println();
            System.out.println("Создаю файл " + filePath + " ...");
            System.out.println();
        }
        return content.toString();
    }

    public String readListTransactions() throws IOException {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                if (!line.trim().equals("")) {
                    content.append(line).append("\n");
                } else {
                    break;
                }
            }
        } catch (IOException e) {
            System.out.println();
            System.out.println("Создаю файл " + filePath + " ...");
            System.out.println();
        }

        String[][] transactionData = getTransactionData(content.toString());

        return dataListTransactionsToString(transactionData);
    }

    public String readMonthlyReport() throws IOException {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            int i = 0;
            while ((line = reader.readLine()) != null) {

                if (line.trim().equals("")) {
                    i = 1;
                }
                if (i == 1) {
                    content.append(line).append("\n");
                }

            }
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

        String[][] reportData = getReportData(content.toString());

        return dataReportToString(reportData);
    }

    @Override
    public String writeSumByMont(String[][][] data) {
        StringBuilder result = new StringBuilder();
        result.append("\n").append("Календарный период,").append("Итог").append("\n");
        for (int i = 0; i < data.length; i++) {
            if (data[i] != null) {
                String year = data[i][0][1].substring(0, 4);
                int monthIndex = Integer.parseInt(data[i][0][1].substring(5, 7));
                String monthName = monthNames[monthIndex - 1];

                double sum = 0;
                for (int j = 0; j < data[i].length; j++) {
                    if (data[i][j] != null) {
                        sum = sum + parseNumberFormat(data[i][j][2]);
                    }
                }
                result.append(monthName).append(" ").append(year).append(",")
                        .append(String.format("%.2f", sum).replace(',', '.')).append("\n");
            }

        }

        return result.toString();
    }

    private static String[][] getTransactionData(String html) {
        String[] rows = html.split("\n");

        String[][] data = new String[rows.length - 1][3];

        for (int i = 0; i < rows.length; i++) {
            String[] cells = rows[i].split(",");
            if (i > 0){
                data[i - 1] = cells;
            }

        }

        return data;
    }

    private static String[][] getReportData(String html) {
        String[] lines = html.trim().split("\n");

        String[][] data = new String[lines.length - 1][2];
        for (int i = 1; i < lines.length; i++) {
            String[] cells = lines[i].split(",");
            data[i - 1][0] = cells[0].trim();
            data[i - 1][1] = cells[1].trim();
        }

        return data;
    }

    private static Double parseNumberFormat(String strNumber) {
        strNumber = strNumber.replace(',', '.');
        return Double.parseDouble(strNumber);
    }

    public void processTransactionFile() throws IOException {
        EnterTheData enteredData = new EnterTheData();
        TransactionsDataCsvArray dataByMonth = new TransactionsDataCsvArray();
        MonthlyTransactionArrays monthlyTransaction = new MonthlyTransactionArrays();

        writeNewData(enteredData);

        String[] dataRead = createDataArray(this.read());

        String[][] allTransaction = dataByMonth.getTransactionsArray(dataRead);

        String[][][] transactionByMonth = monthlyTransaction.splitByMonthAndYear(allTransaction);

        String sumByMonth = this.writeSumByMont(transactionByMonth);

        this.writeDataToFile(sumByMonth);

        System.out.println();
        System.out.println("Новые данные добавлены в файл: " + this.filePath);
    }

    public static String[] createDataArray(String input) {
        String[] substrings = new String[countClosingBraces(input)];

        int startIndex = 0;
        int j = 0;
        for (int i = 0; i < input.length(); i++) {

            if (input.charAt(i) == '\n') {
                if (startIndex != 0) {
                    substrings[j] = input.substring(startIndex, i);
                    j++;
                }
                startIndex = i + 1;
            }
        }

        return substrings;
    }

    public static int countClosingBraces(String input) {
        int count = 0;
        int startIndex = 0;
        for (int i = 0; i < input.length(); i++) {
            if (input.charAt(i) == '\n') {
                if (startIndex != 0) {
                    count++;
                }
                startIndex = i + 1;
            }
        }

        return count;
    }

    private void writeNewData(EnterTheData enteredData) {
        String[] dataTransaction = enteredData.enteredData();

        String input = dataTransaction[0] + "," + dataTransaction[1] + "," + dataTransaction[2];


        String inputLine = input.trim();

        this.writeDataToFile(inputLine);
    }

    public void writeDataToFile(String data) {
        String header = "Текущая дата и время" + "," + "Описание сделки" + "," + "Сумма сделки" + "\n";
        try {
            if (new File(filePath).length() == 0) {
                this.write(header + data);
            } else {
                this.write(this.read() + data);
            }
        } catch (IOException e) {

        }
    }
}

class TransactionsDataCsvArray {
    private static String[][] getDataArray(String[] data) {
        String[][] result = new String[data.length][3];
        for (int i = 0; i < data.length; i++) {
            String[] transaction = new String[3];

            int startIndex = 0;
            int endIndex = data[i].indexOf(',', startIndex);
            transaction[1] = data[i].substring(startIndex, endIndex - 9);

            startIndex = endIndex + 1;
            endIndex = data[i].indexOf(',', startIndex);
            transaction[0] = data[i].substring(startIndex, endIndex).trim();

            startIndex = endIndex + 1;
            endIndex = data[i].length();

            transaction[2] = data[i].substring(startIndex, endIndex).trim();

            result[i] = transaction;
        }

        return result;
    }

    public static String[][] getTransactionsArray(String[] data) {
        return getDataArray(data);
    }

}
