import xogame.XOGame;

public class Exercise01 {
    public static void main(String[] args) {
        XOGame game = new XOGame();
        game.play();
    }
}