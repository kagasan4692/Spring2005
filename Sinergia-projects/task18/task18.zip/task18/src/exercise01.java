public class exercise01 {
    public static void main(String[] args) {

        Rectorate rectorate = new Rectorate();
        rectorate.president = "Юрий Борисович Рубин";
        rectorate.rector = "Артём Игоревич Васильев";

        TrainingUnits trainingUnits1 = new TrainingUnits();
        trainingUnits1.faculties = "Факультет информационных технологий";
        trainingUnits1.department1 =  "Кафедра информационного менеджмента и ИКТ";
        trainingUnits1.department2 =  "Кафедра программной инженерии";
        trainingUnits1.department3 =  "Кафедра кибербезопасности";

        TrainingUnits trainingUnits2 = new TrainingUnits();
        trainingUnits2.faculties = "Факультет программирования";
        trainingUnits2.department1 =  "Кафедра разработки программного обеспечения";
        trainingUnits2.department2 =  "веб-разработки";

        TrainingUnits trainingUnits3 = new TrainingUnits();
        trainingUnits3.faculties = "Факультет дизайна";
        trainingUnits3.department1 =  "Кафедра дизайна и архитектуры";




    }
}
