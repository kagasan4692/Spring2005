public class FileInformation {
    String fileName;
    String absolutePath;
    long size;
    byte[] imageData;
}
