public class exercise02 {
    public static void main(String[] args) {
        final int a = 4, b = 3, c = 5;

        final int d = a > b ? a : b;
        final int max = d > c ? d : c;

        System.out.println(max);
    }


}
