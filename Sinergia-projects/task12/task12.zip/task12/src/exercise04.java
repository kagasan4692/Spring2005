public class exercise04 {
    public static void main(String[] args) {

        int letterInt = (int) 'й';
        for (int i = letterInt + 1; i <= (letterInt + 10); i++) {
            System.out.println((char) i);
        }

    }
}
