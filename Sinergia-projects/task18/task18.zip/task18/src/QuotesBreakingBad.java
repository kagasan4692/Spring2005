public class QuotesBreakingBad {
    String quote;
    String author;
}
