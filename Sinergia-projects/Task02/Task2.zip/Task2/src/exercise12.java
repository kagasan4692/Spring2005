public class exercise12 {
    public static void main(String[] args) {
        String str = "Практика программирования: переменные, ветвления, циклы";
        String strReplace = str.replaceAll("о", "обро");
        System.out.println(strReplace);
    }
}
