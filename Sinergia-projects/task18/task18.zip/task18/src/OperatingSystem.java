public class OperatingSystem {
    String name;
    String developer;
    String latestVersion;
    String kernelType;
    String platform;
}
