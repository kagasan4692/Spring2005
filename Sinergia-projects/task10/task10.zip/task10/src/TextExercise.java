public class TextExercise {
//    Скопировал задание сюда!
//    ЛИШНЕЕ отмечу двойными кавычками "";
//
//    1. (уберите лишнее) Python подходит для разработки под: backend, "frontend", "ios"
//
//    2. "backend", "frontend", ios, android
//
//    3. Java подходит для разработки под:"ios", android, backend, "frontend", "ios", "a"
//
//    4. JavaScript подходит для разработки под: "backend", frontend, "ios", "android"
//
//    5. Php подходит для разработки под: "desktop", web
//
//    6. Kotlin подходит для разработки под:"ios", android, backend, "frontend"
}
