public class TrainingUnits {
    String faculties;

    Departments department = new Departments();
    String department1 = department.department;
    String department2 = department.department;
    String department3 = department.department;
}
