public class exercise06 {
    public static void main(String[] args) {
        int x = 1;

        while (x >= -3) {

            System.out.print(x);

            x = x - 1;

        }
    }
}
// X выводится 5 раз