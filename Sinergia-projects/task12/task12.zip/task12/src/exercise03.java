import java.io.IOException;

public class exercise03 {
    public static void main(String[] args) {

        for (char letter = 'а'; letter <= 'я'; letter++) {
            System.out.println(letter);
        }
    }
}
