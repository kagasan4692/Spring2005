public class exercise12 {
    public static void main(String[] args) {
        double random = Math.random() * 11 + 11;
        int randomNumber = (int) Math.floor(random);

        System.out.println(randomNumber);
    }
}
