public class exercise16 {
    public static void main(String[] args) {
        int a, b, c;
        a = 205;
        b = 1078;
        c = 159;

        int d = Math.max(a, b);
        int max = Math.max(d, c);

        System.out.println(max);
    }
}
