public class exercise02 {
    public static void main(String[] args) {

        short shortA = 10001;
        int intA = shortA;

        System.out.println(intA);
    }
}
