public class exercise07 {
    public static void main(String[] args) {

        int intA = 0;

        boolean booleanA = true;

        if (intA == 1) {
            booleanA = true;
        }

        if (intA == 0) {
            booleanA = false;
        }

        System.out.println(booleanA);

        boolean booleanB = true;
        int intB;

        if (booleanB) {
            intB = 1;
        } else {
            intB = 0;
        }

        System.out.println(intB);

    }
}
