public class Exercise02 {
    public static void main(String[] args) {

        for (int i = 0; i < 10; i++) {int x = 10;}

    }
}
