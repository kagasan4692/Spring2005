public class exercise9 {
    public static void main(String[] args) {
        int i = 49;
        while (i < 100) {
            i = i + 1;
            System.out.println(i);
        }
    }
}
