public class exercise03 {
    public static void main(String[] args) {

        int intA = 100000001;
        long longA = intA;

        System.out.println(longA);
    }
}
